@echo off
chcp 65001 >nul
echo ========================================================
echo   AutoTPA - Budowanie pliku wykonywalnego AutoTPA.exe
echo ========================================================
echo.
echo [1/2] Instalacja bibliotek z pliku requirements.txt...
pip install -r requirements.txt
echo.
echo [2/2] Kompilacja projektu do pojedynczego pliku AutoTPA.exe (PyInstaller)...
pyinstaller --noconfirm --onefile --name AutoTPA ^
    --add-data "Front;Front" ^
    --add-data "sample_images;sample_images" ^
    --hidden-import=uvicorn.logging ^
    --hidden-import=uvicorn.loops ^
    --hidden-import=uvicorn.loops.auto ^
    --hidden-import=uvicorn.protocols ^
    --hidden-import=uvicorn.protocols.http ^
    --hidden-import=uvicorn.protocols.http.auto ^
    --hidden-import=uvicorn.protocols.websockets ^
    --hidden-import=uvicorn.protocols.websockets.auto ^
    --hidden-import=uvicorn.lifespan ^
    --hidden-import=uvicorn.lifespan.on ^
    main.py

echo.
echo ========================================================
echo   GOTOWE! Plik AutoTPA.exe znajduje sie w folderze distecho ========================================================
pause
