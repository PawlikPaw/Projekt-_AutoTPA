import sys
import os
import io
import base64
import webbrowser
import threading
import multiprocessing
from typing import List
from pydantic import BaseModel
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image

from algorytm_TPA import oblicz_kat_tpa
from dicom_helper import dicom_bytes_to_pil

def get_resource_path(relative_path: str) -> str:
    """Zwraca poprawną ścieżkę zarówno w trybie deweloperskim, jak i po spakowaniu PyInstallerem (.exe)."""
    if hasattr(sys, '_MEIPASS'):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)

app = FastAPI(title="AutoTPA - System Analizy RTG")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Próba załadowania modelu YOLOv8-Pose (jeśli plik best.pt lub yolov8n-pose.pt istnieje)
yolo_model = None
try:
    from ultralytics import YOLO
    for model_name in ["best.pt", "yolov8n-pose.pt"]:
        model_path = get_resource_path(model_name)
        if os.path.exists(model_path):
            yolo_model = YOLO(model_path)
            print(f"[INFO] Załadowano model AI: {model_path}")
            break
except Exception as e:
    print(f"[INFO] Praca w trybie symulacji (brak aktywnego modelu YOLO: {e})")

class PointsPayload(BaseModel):
    p1_skokowy: List[float]
    p2_kolanowy: List[float]
    p3_plateau_przod: List[float]
    p4_plateau_tyl: List[float]

def wyznacz_punkty_ai(img: Image.Image):
    """Zwraca 4 punkty kluczowe z modelu YOLOv8-Pose lub inteligentne punkty anatomiczne dopasowane do rozmiaru obrazu."""
    w, h = img.size
    if yolo_model is not None:
        try:
            results = yolo_model(img, verbose=False)
            if len(results) > 0 and results[0].keypoints is not None:
                kpts = results[0].keypoints.xy[0].cpu().numpy()
                if len(kpts) >= 4:
                    return (
                        [round(float(kpts[0][0]), 1), round(float(kpts[0][1]), 1)],
                        [round(float(kpts[1][0]), 1), round(float(kpts[1][1]), 1)],
                        [round(float(kpts[2][0]), 1), round(float(kpts[2][1]), 1)],
                        [round(float(kpts[3][0]), 1), round(float(kpts[3][1]), 1)],
                        "YOLOv8-Pose"
                    )
        except Exception as e:
            print(f"[WARN] Błąd predykcji YOLO, używam punktów domyślnych: {e}")

    # Domyślne proporcje anatomiczne kości piszczelowej na zdjęciu bocznym RTG
    p1 = [round(w * 0.48, 1), round(h * 0.82, 1)]  # Środek stawu skokowego (dół)
    p2 = [round(w * 0.49, 1), round(h * 0.22, 1)]  # Staw kolanowy (góra)
    p3 = [round(w * 0.41, 1), round(h * 0.20, 1)]  # Przednia krawędź plateau
    p4 = [round(w * 0.57, 1), round(h * 0.26, 1)]  # Tylna krawędź plateau
    return p1, p2, p3, p4, "Tryb geometryczny (Domyślny)"

@app.post("/api/analyze")
async def analizuj_rtg(plik: UploadFile = File(...)):
    raw_bytes = await plik.read()
    filename = plik.filename or "obraz.png"

    try:
        if filename.lower().endswith(".dcm"):
            img = dicom_bytes_to_pil(raw_bytes)
        else:
            img = Image.open(io.BytesIO(raw_bytes)).convert("RGB")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Nie udało się wczytać obrazu: {str(e)}")

    w, h = img.size
    p1, p2, p3, p4, tryb = wyznacz_punkty_ai(img)
    kat_tpa = oblicz_kat_tpa(p1, p2, p3, p4)

    # Konwersja obrazu na Base64 PNG, aby frontend mógł wyświetlić także skonwertowane pliki DICOM
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    b64_img = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("utf-8")

    return {
        "status": "sukces",
        "nazwa_pliku": filename,
        "szerokosc": w,
        "wysokosc": h,
        "tryb_detekcji": tryb,
        "kat_tpa": kat_tpa,
        "obraz_base64": b64_img,
        "punkty": {
            "skokowy": p1,
            "kolanowy": p2,
            "plateau_przod": p3,
            "plateau_tyl": p4
        }
    }

@app.post("/api/recalculate")
async def przelicz_kat(payload: PointsPayload):
    try:
        kat = oblicz_kat_tpa(
            payload.p1_skokowy,
            payload.p2_kolanowy,
            payload.p3_plateau_przod,
            payload.p4_plateau_tyl
        )
        return {"status": "sukces", "kat_tpa": kat}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/sample/{sample_name}")
async def pobierz_przyklad(sample_name: str):
    sample_dir = get_resource_path("sample_images")
    fpath = os.path.join(sample_dir, sample_name)
    if not os.path.exists(fpath):
        raise HTTPException(status_code=404, detail="Nie znaleziono przykładowego zdjęcia RTG.")

    img = Image.open(fpath).convert("RGB")
    w, h = img.size
    p1, p2, p3, p4, tryb = wyznacz_punkty_ai(img)
    kat_tpa = oblicz_kat_tpa(p1, p2, p3, p4)

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    b64_img = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("utf-8")

    return {
        "status": "sukces",
        "nazwa_pliku": sample_name,
        "szerokosc": w,
        "wysokosc": h,
        "tryb_detekcji": tryb,
        "kat_tpa": kat_tpa,
        "obraz_base64": b64_img,
        "punkty": {
            "skokowy": p1,
            "kolanowy": p2,
            "plateau_przod": p3,
            "plateau_tyl": p4
        }
    }

# Serwowanie plików statycznych Frontendu
front_dir = get_resource_path("Front")
app.mount("/Front", StaticFiles(directory=front_dir), name="front")

@app.get("/")
def index():
    return FileResponse(os.path.join(front_dir, "index.html"))

@app.get("/style.css")
def style():
    return FileResponse(os.path.join(front_dir, "style.css"))

@app.get("/script.js")
def script():
    return FileResponse(os.path.join(front_dir, "script.js"))

def open_browser():
    webbrowser.open("http://127.0.0.1:8000")

if __name__ == "__main__":
    multiprocessing.freeze_support()
    print("====================================================")
    print("  AutoTPA uruchomione! Adres: http://127.0.0.1:8000 ")
    print("====================================================")
    threading.Timer(1.5, open_browser).start()
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="info")
