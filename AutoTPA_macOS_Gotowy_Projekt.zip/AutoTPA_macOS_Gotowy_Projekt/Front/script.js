
const canvas = document.getElementById('xrayCanvas');
const ctx = canvas.getContext('2d');

let currentImage = new Image();
let imageLoaded = false;
let showOverlay = true;

// Współrzędne w oryginalnej skali obrazu
let origPoints = {
    skokowy: [250, 600],
    kolanowy: [250, 150],
    plateau_przod: [210, 140],
    plateau_tyl: [290, 175]
};
let initialAiPoints = null;
let draggingKey = null;

// Elementy UI
const tpaAngleValue = document.getElementById('tpaAngleValue');
const detectionMode = document.getElementById('detectionMode');
const clinicalAlert = document.getElementById('clinicalAlert');
const surgicalAdvice = document.getElementById('surgicalAdvice');
const coordP1 = document.getElementById('coordP1');
const coordP2 = document.getElementById('coordP2');
const coordP3 = document.getElementById('coordP3');
const coordP4 = document.getElementById('coordP4');

// 1. Wczytywanie przykładowego badania z serwera FastAPI
async function loadSampleCase(sampleFile) {
    try {
        const res = await fetch(`/api/sample/${sampleFile}`);
        if (!res.ok) throw new Error("Błąd pobierania przykładu");
        const data = await res.json();
        applyAnalysisResponse(data);
    } catch (err) {
        console.error("Błąd ładowania przykładu:", err);
    }
}

// 2. Obsługa wgrywania własnego pliku RTG (.png, .jpg, .dcm)
const fileInput = document.getElementById('fileInput');
fileInput.addEventListener('change', async function(e) {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("plik", file);

    tpaAngleValue.innerText = "...";
    try {
        const res = await fetch("/api/analyze", {
            method: "POST",
            body: formData
        });
        const data = await res.json();
        if (res.ok) {
            document.getElementById('breadcrumbs').innerHTML = `Wgrany plik / <strong>${data.nazwa_pliku}</strong>`;
            applyAnalysisResponse(data);
        } else {
            alert("Błąd analizy: " + (data.detail || "Nieznany błąd"));
        }
    } catch (err) {
        alert("Błąd połączenia z serwerem: " + err.message);
    }
});

function applyAnalysisResponse(data) {
    origPoints = {
        skokowy: [...data.punkty.skokowy],
        kolanowy: [...data.punkty.kolanowy],
        plateau_przod: [...data.punkty.plateau_przod],
        plateau_tyl: [...data.punkty.plateau_tyl]
    };
    initialAiPoints = JSON.parse(JSON.stringify(origPoints));

    detectionMode.innerText = data.tryb_detekcji || "AI / Geometryczny";
    updateAngleUI(data.kat_tpa);
    updateCoordsUI();

    currentImage = new Image();
    currentImage.onload = function() {
        imageLoaded = true;
        fitCanvasToContainer();
        drawScene();
    };
    currentImage.src = data.obraz_base64;
}

function fitCanvasToContainer() {
    if (!imageLoaded) return;
    const container = document.getElementById('canvasContainer');
    const maxW = container.clientWidth - 24;
    const maxH = container.clientHeight - 24;
    const ratio = Math.min(maxW / currentImage.width, maxH / currentImage.height);

    canvas.width = Math.round(currentImage.width * ratio);
    canvas.height = Math.round(currentImage.height * ratio);
}

window.addEventListener('resize', () => {
    fitCanvasToContainer();
    drawScene();
});

function toCanvasCoords(pt) {
    const scaleX = canvas.width / currentImage.width;
    const scaleY = canvas.height / currentImage.height;
    return [pt[0] * scaleX, pt[1] * scaleY];
}

function toImageCoords(cx, cy) {
    const scaleX = currentImage.width / canvas.width;
    const scaleY = currentImage.height / canvas.height;
    return [
        Math.max(0, Math.min(currentImage.width, Math.round(cx * scaleX * 10) / 10)),
        Math.max(0, Math.min(currentImage.height, Math.round(cy * scaleY * 10) / 10))
    ];
}

function drawScene() {
    if (!imageLoaded) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(currentImage, 0, 0, canvas.width, canvas.height);

    if (!showOverlay) return;

    const p1 = toCanvasCoords(origPoints.skokowy);
    const p2 = toCanvasCoords(origPoints.kolanowy);
    const p3 = toCanvasCoords(origPoints.plateau_przod);
    const p4 = toCanvasCoords(origPoints.plateau_tyl);

    // 1. Linia osi mechanicznej piszczeli (P1 -> P2) - Cyjan
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(p1[0], p1[1]);
    ctx.lineTo(p2[0], p2[1]);
    ctx.strokeStyle = '#00e5ff';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    // 2. Prosta prostopadła do osi mechanicznej w punkcie P2 (linia referencyjna 90 stopni)
    const vx = p2[0] - p1[0];
    const vy = p2[1] - p1[1];
    const len = Math.hypot(vx, vy) || 1;
    const perpX = -vy / len;
    const perpY = vx / len;
    const refLen = 90;

    ctx.beginPath();
    ctx.setLineDash([6, 4]);
    ctx.moveTo(p2[0] - perpX * refLen, p2[1] - perpY * refLen);
    ctx.lineTo(p2[0] + perpX * refLen, p2[1] + perpY * refLen);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.65)';
    ctx.lineWidth = 1.8;
    ctx.stroke();
    ctx.setLineDash([]);

    // 3. Linia powierzchni stawowej plateau (P3 -> P4) - Pomarańczowy/Złoty
    ctx.beginPath();
    ctx.moveTo(p3[0], p3[1]);
    ctx.lineTo(p4[0], p4[1]);
    ctx.strokeStyle = '#ffab00';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.restore();

    // 4. Rysowanie 4 punktów kluczowych do przeciągania (Drag & Drop)
    const pts = [
        { key: 'skokowy', pos: p1, label: 'P1 (Skokowy)', color: '#00e5ff' },
        { key: 'kolanowy', pos: p2, label: 'P2 (Kolanowy)', color: '#00e5ff' },
        { key: 'plateau_przod', pos: p3, label: 'P3 (Przód)', color: '#ffab00' },
        { key: 'plateau_tyl', pos: p4, label: 'P4 (Tył)', color: '#ffab00' }
    ];

    pts.forEach(item => {
        ctx.beginPath();
        ctx.arc(item.pos[0], item.pos[1], 7, 0, Math.PI * 2);
        ctx.fillStyle = item.color;
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = '#141419';
        ctx.stroke();

        ctx.font = 'bold 12px sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = 'rgba(0,0,0,0.85)';
        ctx.shadowBlur = 4;
        ctx.fillText(item.label, item.pos[0] + 10, item.pos[1] - 8);
        ctx.shadowBlur = 0;
    });
}

// Obsługa przeciągania punktów myszką (Human-in-the-Loop)
canvas.addEventListener('mousedown', function(e) {
    if (!imageLoaded || !showOverlay) return;
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    const keys = ['skokowy', 'kolanowy', 'plateau_przod', 'plateau_tyl'];
    for (const k of keys) {
        const [px, py] = toCanvasCoords(origPoints[k]);
        if (Math.hypot(mx - px, my - py) <= 14) {
            draggingKey = k;
            break;
        }
    }
});

canvas.addEventListener('mousemove', function(e) {
    if (!draggingKey) return;
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    origPoints[draggingKey] = toImageCoords(mx, my);
    updateCoordsUI();
    drawScene();
    recalculateAngleLive();
});

window.addEventListener('mouseup', function() {
    draggingKey = null;
});

async function recalculateAngleLive() {
    try {
        const res = await fetch('/api/recalculate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                p1_skokowy: origPoints.skokowy,
                p2_kolanowy: origPoints.kolanowy,
                p3_plateau_przod: origPoints.plateau_przod,
                p4_plateau_tyl: origPoints.plateau_tyl
            })
        });
        if (res.ok) {
            const data = await res.json();
            updateAngleUI(data.kat_tpa);
        }
    } catch (e) {
        console.error("Błąd przeliczania TPA:", e);
    }
}

function updateCoordsUI() {
    coordP1.innerText = `(${Math.round(origPoints.skokowy[0])}, ${Math.round(origPoints.skokowy[1])})`;
    coordP2.innerText = `(${Math.round(origPoints.kolanowy[0])}, ${Math.round(origPoints.kolanowy[1])})`;
    coordP3.innerText = `(${Math.round(origPoints.plateau_przod[0])}, ${Math.round(origPoints.plateau_przod[1])})`;
    coordP4.innerText = `(${Math.round(origPoints.plateau_tyl[0])}, ${Math.round(origPoints.plateau_tyl[1])})`;
}

function updateAngleUI(angle) {
    tpaAngleValue.innerText = `${angle}°`;
    tpaAngleValue.classList.remove('danger', 'success', 'warning');

    if (angle <= 14.0) {
        tpaAngleValue.classList.add('success');
        clinicalAlert.className = 'alert success';
        clinicalAlert.innerHTML = `<strong>Prawidłowe nachylenie / Stan po TPLO:</strong> Kąt TPA wynosi <strong>${angle}°</strong> i mieści się w bezpiecznym zakresie biomechanicznym.`;
        surgicalAdvice.innerHTML = `Brak konieczności dalszej rotacji odłamów. Kąt nachylenia powierzchni stawowej piszczeli zapewnia stabilność stawu kolanowego.`;
    } else if (angle <= 26.0) {
        tpaAngleValue.classList.add('warning');
        const targetRotation = Math.max(0, (angle - 5.5).toFixed(1));
        clinicalAlert.className = 'alert warning';
        clinicalAlert.innerHTML = `<strong>Przedoperacyjny kąt fizjologiczny:</strong> Kąt TPA wynosi <strong>${angle}°</strong>.`;
        surgicalAdvice.innerHTML = `W przypadku zerwania więzadła krzyżowego doczaszkowego (CrCL) zalecana rotacja plateau podczas zabiegu TPLO o ok. <strong>${targetRotation}°</strong> (do docelowego TPA ~5.5°).`;
    } else {
        tpaAngleValue.classList.add('danger');
        const targetRotation = (angle - 5.5).toFixed(1);
        clinicalAlert.className = 'alert warning';
        clinicalAlert.innerHTML = `<strong>Zwiększone nachylenie plateau:</strong> Kąt TPA wynosi <strong>${angle}°</strong> (wysokie obciążenie więzadła CrCL).`;
        surgicalAdvice.innerHTML = `Wskazana osteotomia TPLO. Wymagana korekta kątowa o <strong>${targetRotation}°</strong> w celu uzyskania pooperacyjnego kąta 5.5°.`;
    }
}

// Przełączanie pacjentów na pasku bocznym
const patientCards = document.querySelectorAll('.patient-card');
const breadcrumbs = document.getElementById('breadcrumbs');

patientCards.forEach(card => {
    card.addEventListener('click', function() {
        patientCards.forEach(c => c.classList.remove('active'));
        this.classList.add('active');
        const name = this.getAttribute('data-name');
        const sample = this.getAttribute('data-sample');
        breadcrumbs.innerHTML = `Pacjenci / ${name} / <strong>Pomiar kąta TPA</strong>`;
        if (sample) loadSampleCase(sample);
    });
});

// Wyszukiwarka pacjentów
document.getElementById('searchInput').addEventListener('input', function(e) {
    const q = e.target.value.toLowerCase();
    patientCards.forEach(card => {
        const text = card.innerText.toLowerCase();
        card.style.display = text.includes(q) ? 'flex' : 'none';
    });
});

// Przycisk Resetuj punkty AI
document.getElementById('btnResetPoints').addEventListener('click', function() {
    if (!initialAiPoints) return;
    origPoints = JSON.parse(JSON.stringify(initialAiPoints));
    updateCoordsUI();
    drawScene();
    recalculateAngleLive();
});

// Pokaż/ukryj osie
document.getElementById('btnToggleLines').addEventListener('click', function() {
    showOverlay = !showOverlay;
    this.classList.toggle('active-tool', showOverlay);
    drawScene();
});

// Przycisk Zatwierdź pomiar
document.getElementById('btnSave').addEventListener('click', function() {
    const originalText = this.innerText;
    this.innerText = 'Zapisano pomiar ✓';
    this.classList.add('btn-success-state');
    setTimeout(() => {
        this.innerText = originalText;
        this.classList.remove('btn-success-state');
    }, 2000);
});

// Eksport raportu
document.getElementById('btnExport').addEventListener('click', function() {
    window.print();
});

// Załaduj pierwszego pacjenta na starcie
window.addEventListener('DOMContentLoaded', () => {
    loadSampleCase('12_preop.png');
});
