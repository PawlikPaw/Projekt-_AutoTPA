import io
import os
import numpy as np
from PIL import Image

try:
    import pydicom
    PYDICOM_AVAILABLE = True
except ImportError:
    PYDICOM_AVAILABLE = False

def dicom_bytes_to_pil(dicom_bytes: bytes) -> Image.Image:
    """Konwertuje surowe bajty pliku DICOM (.dcm) na obiekt PIL Image (skala 0-255)."""
    if not PYDICOM_AVAILABLE:
        raise RuntimeError("Biblioteka pydicom nie jest zainstalowana.")
    dcm = pydicom.dcmread(io.BytesIO(dicom_bytes))
    piksele = dcm.pixel_array.astype(float)
    minimum = np.min(piksele)
    maksimum = np.max(piksele)
    if maksimum > minimum:
        piksele = (piksele - minimum) / (maksimum - minimum) * 255.0
    else:
        piksele = np.zeros_like(piksele)
    if getattr(dcm, "PhotometricInterpretation", "") == "MONOCHROME1":
        piksele = 255.0 - piksele
    piksele = piksele.astype(np.uint8)
    return Image.fromarray(piksele).convert("RGB")
