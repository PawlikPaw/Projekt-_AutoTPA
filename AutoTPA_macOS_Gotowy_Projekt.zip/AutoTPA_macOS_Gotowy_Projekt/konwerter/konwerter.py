import os
import pydicom
import numpy as np
from PIL import Image

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def konwertuj_plik(sciezka_dcm, sciezka_png):
    dane_dicom = pydicom.dcmread(sciezka_dcm)
    piksele = dane_dicom.pixel_array.astype(float)
    
    minimum = np.min(piksele)
    maksimum = np.max(piksele)
    if maksimum > minimum:
        piksele = (piksele - minimum) / (maksimum - minimum) * 255.0
    else:
        piksele = np.zeros_like(piksele)
        
    if getattr(dane_dicom, "PhotometricInterpretation", "") == "MONOCHROME1":
        piksele = 255.0 - piksele
        
    piksele = piksele.astype(np.uint8)
    obraz = Image.fromarray(piksele)
    obraz.save(sciezka_png)

if __name__ == "__main__":
    folder_wejsciowy = os.path.join(BASE_DIR, "surowe_dicom")
    folder_wyjsciowy = os.path.join(BASE_DIR, "gotowe_png")

    os.makedirs(folder_wyjsciowy, exist_ok=True)

    if os.path.exists(folder_wejsciowy):
        for nazwa_pliku in os.listdir(folder_wejsciowy):
            if nazwa_pliku.lower().endswith(".dcm"):
                sciezka_wejsciowa = os.path.join(folder_wejsciowy, nazwa_pliku)
                nowa_nazwa = nazwa_pliku[:-4] + ".png"
                sciezka_wyjsciowa = os.path.join(folder_wyjsciowy, nowa_nazwa)
                konwertuj_plik(sciezka_wejsciowa, sciezka_wyjsciowa)
                print("Przekonwertowano:", nazwa_pliku)
    else:
        print(f"Brak folderu wejściowego: {folder_wejsciowy}")
