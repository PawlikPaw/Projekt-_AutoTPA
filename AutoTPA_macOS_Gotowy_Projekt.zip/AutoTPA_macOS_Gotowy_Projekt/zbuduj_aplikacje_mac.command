#!/bin/bash
cd "$(dirname "$0")"

echo "========================================================"
echo "  AutoTPA (macOS) - Budowanie aplikacji wykonywalnej"
echo "========================================================"

if [ ! -d "venv" ]; then
    echo "[1/3] Tworzenie środowiska wirtualnego Python (venv)..."
    python3 -m venv venv
fi

echo "[2/3] Instalacja bibliotek i PyInstallera..."
./venv/bin/pip install --upgrade pip
./venv/bin/pip install -r requirements.txt

echo "[3/3] Kompilacja projektu do natywnego pliku macOS (separator ':')..."
./venv/bin/pyinstaller --noconfirm --onefile --name AutoTPA     --add-data "Front:Front"     --add-data "sample_images:sample_images"     --hidden-import=uvicorn.logging     --hidden-import=uvicorn.loops     --hidden-import=uvicorn.loops.auto     --hidden-import=uvicorn.protocols     --hidden-import=uvicorn.protocols.http     --hidden-import=uvicorn.protocols.http.auto     --hidden-import=uvicorn.protocols.websockets     --hidden-import=uvicorn.protocols.websockets.auto     --hidden-import=uvicorn.lifespan     --hidden-import=uvicorn.lifespan.on     main.py

echo ""
echo "========================================================"
echo "  GOTOWE! Plik wykonywalny znajduje się w: dist/AutoTPA"
echo "========================================================"
read -p "Naciśnij Enter, aby zakończyć..."
