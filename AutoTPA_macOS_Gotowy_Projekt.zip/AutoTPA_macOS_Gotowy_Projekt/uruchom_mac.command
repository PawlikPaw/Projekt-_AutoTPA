#!/bin/bash
# Automatyczne przejście do folderu projektu
cd "$(dirname "$0")"

echo "========================================================"
echo "  AutoTPA (macOS) - Inicjalizacja i uruchomienie"
echo "========================================================"

# Tworzenie wirtualnego środowiska (venv) - omija blokadę PEP 668 na macOS
if [ ! -d "venv" ]; then
    echo "[1/2] Tworzenie wirtualnego środowiska Python (venv)..."
    python3 -m venv venv
    echo "[2/2] Instalacja wymaganych bibliotek z requirements.txt..."
    ./venv/bin/pip install --upgrade pip
    ./venv/bin/pip install -r requirements.txt
else
    echo "[INFO] Środowisko venv gotowe. Sprawdzanie bibliotek..."
    ./venv/bin/pip install -q -r requirements.txt
fi

echo ""
echo "Uruchamianie serwera AutoTPA na http://127.0.0.1:8000 ..."
echo "(Aby wyłączyć serwer na Macu, wciśnij Control + C lub zamknij okno Terminala)"
echo ""
./venv/bin/python main.py
